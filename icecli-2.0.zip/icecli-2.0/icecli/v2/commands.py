# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2011, 2013. All Rights Reserved.
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
__author__ = 'asyousse'

import os
import sys
import configparser
import json
import traceback
import time
from datetime import datetime
import tempfile
import tarfile
from functools import wraps
import subprocess
import requests
#import lib.requests as requests


VERBOSE = False
DEBUG_CLI = os.environ.get('DEBUG_CLI', 'False')

PROG_NAME = os.environ.get('PROG_NAME','ice')  #This is the program name which will appear in help messages
DOCKER_PATH = os.environ.get('DOCKER_PATH','docker')  #The path of the original docker cli
CF_PATH = os.environ.get('CF_PATH','cf')  #The path of the original Bluemix cf cli
CF_API_URL = os.environ.get('CF_API_URL','https://api.ng.bluemix.net')
CF_FLAG=False

#CCS_HOST_URL = os.environ.get('CCS_HOST_URL','https://api-ice.ng.bluemix.net/v1.0/containers')
CCS_HOST = os.environ.get('CCS_HOST','api-ice.ng.bluemix.net')
CCS_PROTO='https://'
CCS_RELPATH='/v2/containers'
CCS_HOST_URL=CCS_PROTO+CCS_HOST+CCS_RELPATH

REG_HOST = os.environ.get('REG_HOST','registry-ice.ng.bluemix.net')

X_AUTH_TOKEN = os.environ.get('X_AUTH_TOKEN','')
API_KEY = os.environ.get('API_KEY','')

OS_USER = os.environ.get('OS_USERNAME','')
OS_TENANT = os.environ.get('OS_TENANT_NAME','')
OS_PASSWORD = os.environ.get('OS_PASSWORD','')

CFG_FILE = os.environ.get('ICE_CFG_FILE','ice-cfg.ini')

#Formatting globals
HSEP=''
VSEP=' '

def debug(arg):
    if DEBUG_CLI.upper() == 'TRUE' or VERBOSE:
        print ("@"+str(datetime.now())+" - "+str(arg))
    return

def debug_exc():
    if DEBUG_CLI.upper() == 'TRUE' or VERBOSE:
        print ("@"+str(datetime.now())+" - Exception trace:")
        traceback.print_exc()
    return

def _get_cfg_filename():
    homedir = os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('ICE_HOME', homedir +sep+'.ice')
    if not os.path.isdir(filedir):
        debug(filedir+' does not exist... attempting to create\n')
        try:
            os.makedirs(filedir)
        except Exception:
            sys.stdout.write('Error creating dir ' +filedir + ' ... using working dir\n')
            debug_exc()
            return CFG_FILE
    filename=filedir+sep+CFG_FILE
    return filename

def load_config():
    global CCS_HOST, X_AUTH_TOKEN,\
        PROG_NAME, DOCKER_PATH,\
        DEBUG_CLI, API_KEY, REG_HOST, OS_USER, OS_TENANT, \
        CF_API_URL, CF_PATH

    filename = _get_cfg_filename()
    if not os.path.isfile(filename):
        debug(filename+' does not exist ... using defaults\n')
    try:
        config = configparser.ConfigParser()
        config.read(filename)
        if "ccs_host" in config['DEFAULT']:
                CCS_HOST = config['DEFAULT']['CCS_HOST']
                _set_host_url(CCS_HOST)
        if 'x_auth_token' in config['DEFAULT']:
                X_AUTH_TOKEN = config['DEFAULT']['X_AUTH_TOKEN']
        if 'prog_name' in config['DEFAULT']:
                PROG_NAME = config['DEFAULT']['PROG_NAME']
        if 'docker_path' in config['DEFAULT']:
                DOCKER_PATH = config['DEFAULT']['DOCKER_PATH']
        if 'debug_cli' in config['DEFAULT']:
                DEBUG_CLI = config['DEFAULT']['DEBUG_CLI']
        if 'api_key' in config['DEFAULT']:
                API_KEY = config['DEFAULT']['API_KEY']
        if 'reg_host' in config['DEFAULT']:
                REG_HOST = config['DEFAULT']['REG_HOST']
        if 'os_user' in config['DEFAULT']:
                OS_USER = config['DEFAULT']['OS_USER']
        if 'os_tenant' in config['DEFAULT']:
                OS_TENANT = config['DEFAULT']['OS_TENANT']
        if 'cf_path' in config['DEFAULT']:
                CF_PATH = config['DEFAULT']['CF_PATH']
        if 'cf_api_url' in config['DEFAULT']:
                CF_API_URL = config['DEFAULT']['CF_API_URL']
    except Exception:
        sys.stdout.write('Error loading configuration.'+'\n')
        debug_exc()
    return

def store_config():
    #caller must surround call by try/except
    config = configparser.ConfigParser()
    config['DEFAULT'] = {
        'CCS_HOST': CCS_HOST,
        'X_AUTH_TOKEN': X_AUTH_TOKEN,
        'PROG_NAME': PROG_NAME,
        'DOCKER_PATH': DOCKER_PATH,
        'DEBUG_CLI': DEBUG_CLI,
        'API_KEY': API_KEY,
        'REG_HOST': REG_HOST,
        'OS_USER': OS_USER,
        'OS_TENANT': OS_TENANT,
        'CF_PATH': CF_PATH,
        'CF_API_URL': CF_API_URL
    }
    filename = _get_cfg_filename()
    with open(filename, 'w') as configfile:
        config.write(configfile)
    return

def _load_cf_token():
    #get cloud foundry token as is, with leading "bearer " word
    tok=""
    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return ""
    #load file and obtain AccessToken
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        tok=data["AccessToken"]
    except:
        debug('Error reading from '+filename)
        debug_exc()
    return tok

'''
#deprecated
def _load_cf_token_and_space():
    #get cloud foundry token
    tok=""
    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return ""
    #load file and obtain AccessToken
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        tok=data["AccessToken"]
        pos=tok.find("bearer")
        if pos ==-1:
            debug("bearer token not found")
            return ""
        tok=tok[pos+7:]
        tok+="|"+data["SpaceFields"]["Guid"]
        debug("Bearer token | Space GUID: "+tok)
    except:
        debug('Error reading from '+filename)
        debug_exc()
    return tok
#deprecated
def _get_auth_token():
    tok=""
    if X_AUTH_TOKEN != '':
        debug("using api key token")
        tok=X_AUTH_TOKEN
    else:
        debug("using bearer token and space id")
        tok=_load_cf_token_and_space()
    return tok
'''

def _get_bearer_and_space():
    bearer=""
    space=""
    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return "",""
    #load file and obtain AccessToken
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        bearer=data["AccessToken"]
        pos=bearer.find("bearer")
        if pos ==-1:
            pos=bearer.find("Bearer")
            if pos ==-1:
                debug("bearer token not found")
                return "", ""
        bearer=bearer[pos+7:]
        space=data["SpaceFields"]["Guid"]
        debug("Bearer: "+bearer)
        debug("Space Guid: "+space)
    except:
        debug('Error reading from '+filename)
        debug_exc()
    return bearer, space

def _get_bearer_and_org():
    bearer=""
    org=""
    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return "",""
    #load file and obtain AccessToken
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        bearer=data["AccessToken"]
        pos=bearer.find("bearer")
        if pos ==-1:
            pos=bearer.find("Bearer")
            if pos ==-1:
                debug("bearer token not found")
                return "", ""
        bearer=bearer[pos+7:]
        org=data["OrganizationFields"]["Guid"]
        debug("Bearer: "+bearer)
        debug("Org Guid: "+org)
    except:
        debug('Error reading from '+filename)
        debug_exc()
    return bearer, org

def _get_cf_config_info():
    spaceid=""
    spacename=""
    orgid=""
    orgname=""

    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return "","","",""
    #load file and obtain AccessToken
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        orgid=data["OrganizationFields"]["Guid"]
        orgname=data["OrganizationFields"]["Name"]
        spaceid=data["SpaceFields"]["Guid"]
        spacename=data["SpaceFields"]["Name"]
    except:
        debug('Error reading from '+filename)
        debug_exc()
    return spaceid, spacename, orgid, orgname

def _get_registry_auth():
    if API_KEY != ''  and  not CF_FLAG:
        debug("using api key")
        return "apikey", API_KEY
    else:
        debug("using bearer token")
        bearer, org = _get_bearer_and_org()
        return "bearer", bearer+"|"+org

def _create_headers():
    if X_AUTH_TOKEN != '' and  not CF_FLAG:
        debug("using api key token")
        headers = {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'X-Auth-Token': X_AUTH_TOKEN
        }
    else:
        debug("using bearer token and space id")
        bearer, space = _get_bearer_and_space()
        headers = {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'X-Auth-Token': bearer,
            'X-Auth-Project-Id': space
        }
    return headers

def _append_header(h, key, val):
    h[key] = val
    return h

def _remove_header(h, key):
    if key in h:
        h.pop(key)
    return h

'''
#deprecated
def _get_registry_token():
    tok=""
    if API_KEY != '':
        debug("using api key")
        tok=API_KEY
    else:
        debug("using bearer token and space id")
        tok=_load_cf_token_and_space()
    return tok
'''

def _set_host_url(host):
    global CCS_HOST_URL, CCS_HOST

    CCS_HOST=host
    prefix=''
    if host.find('://') == -1:
        prefix=CCS_PROTO

    postfix=''
    if host.find('/containers') == -1:
        postfix=CCS_RELPATH

    CCS_HOST_URL=prefix+host+postfix
    return CCS_HOST_URL

def _set_reg_host(host):
    global REG_HOST
    REG_HOST=host
    return

def _set_auth_token(tok):
    global X_AUTH_TOKEN
    X_AUTH_TOKEN=tok
    return

def _set_api_key(api_key):
    global API_KEY
    API_KEY = api_key
    return

def _set_user(user):
    global OS_USER
    OS_USER = user
    return

def _set_tenant(tenant):
    global OS_TENANT
    OS_TENANT = tenant
    return

def _set_psswd(psswd):
    global OS_PASSWORD
    OS_PASSWORD = psswd
    return

def _set_bm_api_url(api_url):
    global CF_API_URL
    CF_API_URL = api_url
    return

def _print_err(r):
    sys.stdout.write("Command failed with container cloud service\n")
    if r.status_code == 401 :
        sys.stdout.write("Unauthorized failure\n")
    else:
        sys.stdout.write(r.text +'\n')
    debug("Return code: "+ str(r.status_code) +"   Return reason: " +r.reason)
    return

def _refresh_cf_tokens():
    sys.stdout.write("Refreshing cf tokens\n")

    #get cloud foundry authorization url, bearer token, and refresh token
    homedir=os.path.expanduser("~")
    sep=os.sep
    filedir=os.environ.get('CF_HOME', homedir+sep+'.cf')
    filename=filedir+sep+'config.json'
    debug('config.json path: '+filename)
    if not os.path.isfile(filename):
        sys.stdout.write(filename+' is not a valid path\n')
        return -1
    #load file and obtain token
    try:
        json_data=open(filename)
        data = json.load(json_data)
        json_data.close()
        refresh_tok=data["RefreshToken"]
        bearer_tok=data["AccessToken"]
        auth_url=data["AuthorizationEndpoint"]
    except:
        sys.stdout.write('Error reading from '+filename+'\n')
        debug_exc()
        return -1

    #call BM auth url
    auth_url+="/oauth/token"
    debug("auth_url: "+auth_url)
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    debug("Headers: "+str(headers))
    body = "grant_type=refresh_token&refresh_token="+refresh_tok
    debug("Body: "+body)
    try:
        r = requests.post(auth_url, body, headers=headers, auth=("cf",""))
        if r.status_code == requests.codes.ok :
            resp=r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            #Extract new tokens
            new_bearer="bearer "+resp["access_token"]
            new_refresh=resp["refresh_token"]
        else:
            sys.stdout.write("Failed to refresh token\n")
            debug("Refresh token req error code: "+ str(r.status_code))
            debug("Refresh token req error reason: "+ r.reason)
            return -1
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to BM Authorization Endpoint \n")
        debug_exc()
        return -1

    #store new bearer and refresh tokens in ~/.cf/config.json
    try:
        json_data=open(filename,'w')
        data["RefreshToken"]=new_refresh
        data["AccessToken"]=new_bearer
        json.dump(data, json_data)
        json_data.close()
    except:
        sys.stdout.write('Error writing to '+filename+'\n')
        debug_exc()
        return -1
    return 0

def _check_auth_refresh_err(r, num_attempts):
    if r.status_code != 401 :
        return -1
    elif X_AUTH_TOKEN != '':
        return -1
    elif num_attempts > 1 :
        return -1
    return _refresh_cf_tokens()

#Decorator function. Auth wrapper function
def auth_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        #debug('First attempt')
        err, resp=f(*args, **kwargs)
        if err == 0 or resp == None:
            #success OR exception connecting to service
            return err, resp
        if _check_auth_refresh_err(resp, num_attempts=1) < 0 :
            #error is not auth error OR using api token
            return err, resp
        #Token refreshed, attempt command again
        debug('Second attempt')
        err, resp=f(*args, **kwargs)
        return err, resp
    return decorated_function

def _short_image_name(img):
    if img.find(REG_HOST) != -1:
        pos=img.find('/')
        short_name=img[pos+1:]
    else:
        short_name=img
    return short_name

def _strip_image_tag(img):
    pos=img.find(":")
    if pos != -1:
        img=img[:pos]
    return img

def _get_image_tag(img):
    tag="latest"
    pos=img.find(":")
    if pos != -1:
        tag=img[pos+1:]
    return tag

def no_command(ns):
    sys.stdout.write ('for help, use --help or -h \n')
    return 0

def login(ns):
    global CF_FLAG
    if ns.api_key:
        _set_api_key(ns.api_key)
    if ns.host:
        _set_host_url(ns.host)
    if ns.reg_host:
        _set_reg_host(ns.reg_host)

    if ns.cf or not ns.api_key:   #cf is the default
        CF_FLAG=True
        #exec cf login
        cmd = CF_PATH + ' login'
        if ns.user:
            cmd += ' -u ' + ns.user
        if ns.psswd:
            cmd += ' -p ' + ns.psswd
        if ns.org:
            cmd += ' -o ' + ns.org
        if ns.space:
            cmd += ' -s ' + ns.space
        if ns.api_url:
            _set_bm_api_url(ns.api_url)
        if CF_API_URL != '':
            cmd += ' -a ' + CF_API_URL

        debug ("Executing: "+cmd)
        try:
            #os.spawnvp(os.P_WAIT, CF_PATH, argv)
            #os.execvp(CF_PATH, argv)
            r=os.system(cmd)
            debug('cf exit level: '+str(r))
            if r == 0:
                #success
                #check if space was set, otherwise fail
                bearer, space = _get_bearer_and_space()
                if space == "":
                    sys.stdout.write("\nAuthentication incomplete... Please try again and specify Space\n")
                    return -1
                debug("cf login succeeded. Can access: "+CCS_HOST_URL)
            else:
                sys.stdout.write("Authentication failed with container cloud service. Login endpoint: "+CF_API_URL+ " Containers URL: "+CCS_HOST_URL+"\n")
                return -1
        except:
            sys.stdout.write ("Could not find or execute " + CF_PATH + " \n")
            sys.stdout.write ("Could not login to Bluemix \n")
            debug_exc()
            return -1
    else:
        #use api key to login
        if API_KEY=="":
            sys.stdout.write('Please provide key, cannot proceed with authentication\n')
            return -1
        if CCS_HOST_URL=="":
            sys.stdout.write('Please provide target container cloud service host, cannot proceed with authentication\n')
            return -1
        #get auth token from ccs api server
        url = CCS_HOST_URL+"/tokens"
        debug("request url: "+url)
        data = json.dumps({
            "auth":{
                "key": API_KEY
            }
        })
        debug('Post body: '+data)
        headers = {
            'content-type': 'application/json',
            'Accept': 'application/json'
        }
        try:
            r = requests.post(url, data, headers=headers)
            if r.status_code == requests.codes.ok :
                tok=r.text
                debug('token='+tok)
                _set_auth_token(tok)
            else:
                sys.stdout.write("Authentication failed with container cloud service at "+CCS_HOST_URL+"\n")
                _print_err(r)
                return -1
        except requests.exceptions.RequestException as e:
            sys.stdout.write("Authentication failed - Could not connect to container cloud service at "+CCS_HOST_URL+"\n")
            debug_exc()
            return -1
    #Store configuration in ~/.ice/ice-cfg.ini
    try:
        if CF_FLAG:
            _set_auth_token("")
        store_config()
        sys.stdout.write ("Authentication with container cloud service at " + CCS_HOST_URL + " completed successfully\n")
        sys.stdout.write ("You can issue commands now to the container service\n \n")
    except IOError as e:
        sys.stdout.write("Authentication failed - Could not store configuration locally \n")
        debug_exc()
        return -1

    sys.stdout.write ("Proceeding to authenticate with the container cloud registry at "+REG_HOST+"\n")
    #docker login to registry
    if REG_HOST=="":
        sys.stdout.write('Please provide container cloud registry host, cannot authenticate with registry \n')
        return -2
    email='a@b.c'
    user, psswd = _get_registry_auth()
    argv=[ DOCKER_PATH, 'login', '-u', user, '-p', psswd, '-e', email, REG_HOST ]
    debug (argv)
    try:
        os.execvp(DOCKER_PATH, argv)
    except:
        sys.stdout.write ("Could not find or execute " + DOCKER_PATH + " \n")
        sys.stdout.write ("Could not log to cloud registry at "+REG_HOST+"\n")
        debug_exc()
        return -2
    return 0

def tlogin(ns):
    if ns.tenant:
        _set_tenant(ns.tenant)
    if ns.user:
        _set_user(ns.user)
    if ns.psswd:
        _set_psswd(ns.psswd)
    if ns.host:
        _set_host_url(ns.host)
    if ns.reg_host:
        _set_reg_host(ns.reg_host)

    if OS_TENANT=="" or OS_USER=="" or OS_PASSWORD=="":
        sys.stdout.write('Please provide credentials, cannot proceed with authentication\n')
        return -1
    if CCS_HOST_URL=="":
        sys.stdout.write('Please provide target container cloud service host, cannot proceed with authentication\n')
        return -1
    #get auth token from ccs api server
    url = CCS_HOST_URL+"/tokens"
    debug("request url: "+url)
    data = json.dumps({
        "auth":{
            "tenantName": OS_TENANT,
            "passwordCredentials": {
                "username":OS_USER,
                "password":OS_PASSWORD
            }
        }
    })
    debug('Post body: '+data)
    headers = {
        'content-type': 'application/json',
        'Accept': 'application/json'
    }
    try:
        r = requests.post(url, data, headers=headers)
        if r.status_code == requests.codes.ok:
            tok=r.text
            debug('token='+tok)
            _set_auth_token(tok)
        else:
            sys.stdout.write("Authentication failed with container cloud service\n")
            _print_err(r)
            return -1
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Authentication failed - Could not connect to container cloud service \n")
        debug_exc()
        return -1
    try:
        store_config()
        sys.stdout.write ("Authentication with container cloud service completed successfully\n")
        sys.stdout.write ("You can issue commands now to the container service\n \n")
    except IOError as e:
        sys.stdout.write("Authentication failed - Could not store auth token locally \n")
        debug_exc()
        return -1

    sys.stdout.write ("Proceeding to authenticate with the container cloud registry as well...\n")
    #docker login to registry
    if REG_HOST=="":
        sys.stdout.write('Please provide container cloud registry host, cannot authenticate with registry \n')
        return -2
    email='a@b.c'
    argv=[ DOCKER_PATH, 'login', '-u', OS_USER, '-p', OS_PASSWORD, '-e', email, REG_HOST ]
    debug (argv)
    try:
        os.execvp(DOCKER_PATH, argv)
    except:
        sys.stdout.write ("Could not find or execute " + DOCKER_PATH + " \n")
        sys.stdout.write ("Could not log to cloud registry \n")
        debug_exc()
        return -2

    return 0

def _print_containers(jobj, PublicIP=True):
    w1=[36, 22, 10, 30, 0, 12, 8, 15, 15] #, 14]
    w={
        "Id": 36,
        "Name": 22,
        "Group": 10,
        "Image": 30,
        "Cmd": 0,
        "Created": 12,
        "Status": 8,
        "PrivIP": 15,
        "PubIP": 15,
        "Ports": 6
    }
    hsep=HSEP
    vsep=VSEP

    #print separator line
    '''
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep )
    sys.stdout.write ('\n')
    '''
    for x in w:
        for i in range(0, w[x]+1):
            sys.stdout.write (hsep )
    sys.stdout.write ('\n')

    #print header
    sys.stdout.write ( 'Container Id'.ljust(w["Id"])[:w["Id"]] +vsep)
    sys.stdout.write ( 'Name'.ljust(w["Name"])[:w["Name"]] +vsep )
    sys.stdout.write ( 'Group'.ljust(w["Group"])[:w["Group"]] +vsep )
    sys.stdout.write ( 'Image'.ljust(w["Image"])[:w["Image"]] +vsep)
    sys.stdout.write ( 'Created'.ljust(w["Created"])[:w["Created"]] +vsep )
    sys.stdout.write ( 'State'.ljust(w["Status"])[:w["Status"]] +vsep )
    sys.stdout.write ( 'Private IP'.ljust(w["PrivIP"])[:w["PrivIP"]] +vsep )
    if PublicIP:
        sys.stdout.write ( 'Public IP'.ljust(w["PubIP"]) +vsep)
    sys.stdout.write ( 'Ports'.ljust(w["Ports"]) )
    sys.stdout.write('\n')

    #print separator line
    '''
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')
    '''
    for x in w:
        for i in range(0, w[x]+1):
            sys.stdout.write (hsep )
    sys.stdout.write ('\n')

    #iterate over jobj
    for x in jobj:
        #strip registry name from image name to shorten it
        img = x['Image']
        img=_short_image_name(img)

        sys.stdout.write ( x['Id'].ljust(w["Id"])[:w["Id"]] +vsep)
        sys.stdout.write ( x['Name'].ljust(w["Name"])[:w["Name"]] +vsep)
        if "Group" in x:
            if "Name" in x["Group"]:
                sys.stdout.write(x["Group"]["Name"].ljust(w["Group"])[:w["Group"]] + vsep)
            else:
                sys.stdout.write(' '.ljust(w["Group"])[:w["Group"]] +vsep)
        else:
            sys.stdout.write(' '.ljust(w["Group"])[:w["Group"]] +vsep)
        sys.stdout.write ( img.ljust(w["Image"])[:w["Image"]] +vsep)
        if (isinstance(x['Created'], float)) or (isinstance(x['Created'], int)):
            sys.stdout.write ( time.ctime(x['Created'])[4:].ljust(w["Created"])[:w["Created"]] +vsep)
        if "ContainerState" in x:
            sys.stdout.write ( x['ContainerState'].ljust(w["Status"])[:w["Status"]] +vsep)
        elif "Status" in x:
            sys.stdout.write ( x['Status'].ljust(w["Status"])[:w["Status"]] +vsep)
        else:
            sys.stdout.write ( ' '.ljust(w["Status"])[:w["Status"]] +vsep)

        if 'IpAddress' in x['NetworkSettings'] and x['NetworkSettings']['IpAddress']!= None:
            sys.stdout.write ( x['NetworkSettings']['IpAddress'].ljust(w["PrivIP"])[:w["PrivIP"]] +vsep)
        else:
            sys.stdout.write(' '.ljust(w["PrivIP"]) +vsep)

        if PublicIP:
            if 'PublicIpAddress' in x['NetworkSettings'] and x['NetworkSettings']['PublicIpAddress']!= None:
                sys.stdout.write ( x['NetworkSettings']['PublicIpAddress'].ljust(w["PubIP"])[:w["PubIP"]] +vsep)
            else:
                sys.stdout.write(' '.ljust(w["PubIP"]) +vsep)

        if "Ports" in x:
            sys.stdout.write ( str(x['Ports']))

        sys.stdout.write('\n')

        '''
        #
        #print line 2 of the same record to accommodate long strings
        #
        sys.stdout.write ( x['Id'].ljust(2*w[0])[w[0]:2*w[0]] +vsep)
        sys.stdout.write ( x['Name'].ljust(2*w[1])[w[1]:2*w[1]] +vsep)
        sys.stdout.write ( img.ljust(2*w[2])[w[2]:2*w[2]] +vsep)

        if x['Command']:
            sys.stdout.write ( x['Command'].ljust(2*w[3])[w[3]:2*w[3]] +vsep)
        else:
            sys.stdout.write ( ' '.ljust(w[3])[:w[3]] +vsep)

        sys.stdout.write ( ' '.ljust(w[4])[:w[4]] +vsep)
        sys.stdout.write ( ' '.ljust(w[5])[:w[5]] +vsep)
        sys.stdout.write(' '.ljust(w[6]) +vsep)
        sys.stdout.write(' '.ljust(w[7]) +vsep)
        #sys.stdout.write ( s.ljust(2*w[8])[w[8]:2*w[8]] )
        sys.stdout.write('\n')
        '''
    #print separator line
    '''
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')
    '''
    for x in w:
        for i in range(0, w[x]+1):
            sys.stdout.write (hsep )
    sys.stdout.write ('\n')

    return

def _print_container_ids(jobj):
    #iterate over jobj
    for x in jobj:
        sys.stdout.write ( x['Id']+"  " )
        if "Group" in x:
            if "Name" in x["Group"]:
                sys.stdout.write(x["Group"]["Name"])
        sys.stdout.write('\n')
    return

@auth_required
def ps(ns):
    #test formatting
    '''jobj=json.dumps([
          {
                 "Command": "echo 1",
                 "Created": 1367854155,
                 "Id": "c827e716-5aac-408b-a628-e5da55ca051a-junk",
                 "ImageId": "c827e716-5aac-408b-a628-e5da55ca051a",
                 "Image": "docker-registry.mybluemix.net/alchemy/ccsapi",
                 "Name": "alaa-cont1-test",
                 "NetworkSettings": {
                         "IpAddress": "192.123.12.13"

                 },
                 "Ports":[2222, 3333],
                 "SizeRootFs":0,
                 "SizeRw":0,
                 "Status": "Running"
         },
         {
                 "Command": "/bin/bash -c 'hello world'",
                 "Created": 1367884155,
                 "Id": "d123416-",
                 "ImageId": "d123416-5cddc-408b-a628-e5da55ca011a",
                 "Image": "ubuntu",
                 "Name": "cont2",
                 "NetworkSettings": {
                         "IpAddress": "192.123.12.15",
                         "PublicIpAddress": null
                 },
                 "Ports":[2224, 3333,2225],
                 "SizeRw":12288,
                 "SizeRootFs":0,
                 "Status": "Shutdown"
         }
    ])
    _print_containers( json.loads(jobj) )
    return 0, None
    '''

    params="?"
    if ns.all:
        params+="all=true"
    else:
        params+="all=false"
    if ns.num:
        params+="&limit="+str(ns.num)
    if ns.size:
        params+="&size=true"
    else:
        params+="&size=false"

    url = CCS_HOST_URL+"/json"+params
    debug("request url: "+url)

    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            resp=r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            if ns.quiet:
                _print_container_ids( resp )
            else:
                _print_containers( resp )
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service \n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def run(ns):
    params=""
    if ns.name:
        params="?name="+ns.name
    else:
        sys.stdout.write('Please specify a name for your container using --name or -n option \n')
        return -1, None
    mem=256
    if ns.memory:
        mem=ns.memory
    env=[]
    if ns.env:
        env=ns.env
    vol=[]
    if ns.vol:
        vol=ns.vol
        for x in vol:
            pos=x.find(":")
            if pos < 1  or  len(x) < (pos+2) :
                sys.stdout.write('Invalid --volume or -v syntax. Use -v volumeName:containerPath[:ro]\n')
                return -1, None
    ports=[]
    if ns.port:
        ports=ns.port

    sshkey=""
    if ns.sshkey :
        sshkey=ns.sshkey
    '''
    shares=1024
    if ns.shares:
        shares=ns.shares
    cpus=2
    if ns.cpus:
        mem=ns.cpus
    workdir=""
    if ns.workdir:
        workdir=ns.workdir
    '''
    cmd=[]
    if ns.CMD:
        cmd=ns.CMD

    #image is mandatory positional arg, so it should be found
    image=ns.IMAGE
    if image.find(REG_HOST) == -1:
        image = REG_HOST+'/'+image

    #Currently supported flavors:
    #(256,1) (512,2) (1024,4) (2048,8)
    if not mem in [256, 512, 1024, 2048]:
        sys.stdout.write('Invalid configuration request. Allowed memory configurations are 256, 512, 1024, or 2048 (MB).\n')
        return -1, None
    else:
        cpus = int(mem / 256)

    url = CCS_HOST_URL+"/create"+params
    debug("request url: "+url)

    data = {
             "Memory": mem,
             "CpuShares": 1024,
             "NumberCpus": cpus,
             "Env": env ,
             "Cmd": cmd,
             "Image": image,
             "WorkingDir": "",
             "Volumes": vol
    }

    headers = _create_headers()
    #bind to bluemix app if specified
    if ns.app:
        data["BluemixApp"]= ns.app
        CF_TOKEN=_load_cf_token()
        if len(CF_TOKEN) == 0 :
            sys.stdout.write('Could not find cloud foundry token.\n')
            sys.stdout.write('Please install CF command tool in order to be able to bind to Bluemix app.\n')
            return -1, None
        if API_KEY!="":
            headers=_append_header(headers,'X-API-Key', API_KEY)
            headers=_append_header(headers,'X-CF-Token', CF_TOKEN)

    if ns.sshkey:
        sys.stdout.write('Please note that the image must include a running ssh daemon in order to be able to use ssh key\n')
        data["KeyName"]=ns.sshkey
        if not 22 in ports:
            ports.append(22)
            sys.stdout.write('Port 22 was automatically exposed for ssh\n')
    data["Public_ports"]=ports

    body = json.dumps(data)
    debug("Post body: "+body)
    debug("Headers: "+str(headers))
    try:
        r = requests.post(url, body, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            sys.stdout.write (resp["Id"] +"\n")
            if "Warnings" in resp  and len(resp["Warnings"])>0:
                sys.stdout.write ("Warnings: "+ resp["Warnings"] +"\n")
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def inspect(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/json"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            sys.stdout.write( json.dumps( r.json(), sort_keys=True, indent=4, separators=(',', ': ')) +'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def logs(ns):
    cont = ns.CONTAINER
    param=""
    if ns.stderr:
        param="?stderr"
    url = CCS_HOST_URL+"/"+cont+"/logs"+param
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers, stream=True)
        if r.status_code == requests.codes.ok :
            #sys.stdout.write( r.text )
            #sys.stdout.write( '\n' )
            for line in r.iter_lines():
                # filter out keep-alive new lines
                if line:
                    sys.stdout.write(str(line))
                    sys.stdout.write('\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def build(ns):
    if ns.quiet:
        params="?q=true"
    else:
        params="?q=false"
    if ns.tag:
        params += "&t="+ns.tag
    if ns.no_cache:
        params += "&nocache=true"
    if ns.pull:
        params+="&pull=true"
    '''
    if ns.no_rm:
        params += "&rm=false"   #docker default is rm=true
    if ns.force_rm:
        params += "&forcerm=true"
    '''
    url = CCS_HOST_URL+"/build"+params
    debug("request url: "+url)

    #tar ns.PATH
    f = tempfile.NamedTemporaryFile(delete=False)
    temptarfile = f.name
    f.close()
    #This syntax has a problem with tarfile in python 2.6.6
    #with tarfile.open(temptarfile, "w:gz") as tar:
    #    tar.add(ns.PATH, arcname=".")
    try:
        tar=tarfile.open(temptarfile, "w:gz")
        tar.add(ns.PATH, arcname="./")
        tar.close()
        fsize = os.path.getsize(temptarfile)
        debug('Created gzipped tarfile - '+temptarfile)
        sys.stdout.write("zipped tar size: "+str(fsize)+"\n")
    except Exception as e:
        sys.stdout.write('Command failed - error in tar\'ing input\n')
        debug_exc()
        return -1, None

    #Send request
    headers = _create_headers()
    #headers=_append_header(headers, 'content-type', 'application/tar')
    headers=_append_header(headers, 'content-type', 'application/x-gtar')
    headers=_append_header(headers, 'Content-Length', str(fsize))
    debug(str(headers))
    sys.stdout.write("Posting "+str(fsize)+" bytes... It may take a while...\n")
    ret=0
    try:
        with open(temptarfile, 'rb') as f:
            r = requests.post(url, data=f, headers=headers, stream=True)
            if r.status_code == 200 :
                for line in r.iter_lines():
                    # filter out keep-alive new lines
                    if line:
                        #sys.stdout.write(str(line)+'\n')
                        try:
                            js = json.loads(line.decode("utf-8"))
                            if "stream" in js:
                                sys.stdout.write(js["stream"])
                            elif "id" in js:
                                sys.stdout.write(js["id"]+": ")
                                if "status" in js:
                                    sys.stdout.write(js["status"]+" ")
                                if "progress" in js:
                                    sys.stdout.write(js["progress"])
                                sys.stdout.write('\n')
                            elif "status" in js:
                                sys.stdout.write(js["status"])
                                sys.stdout.write('\n')
                            else:
                                sys.stdout.write(str(js)) #sys.stdout.write(json.loads(line))
                                sys.stdout.write('\n')
                        except Exception as e:
                            #sys.stdout.write(str(line)+'\n')
                            pass
                ret=0
            else:
                _print_err(r)
                ret= -1
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        ret= -2
    except Exception as e:
        sys.stdout.write('Command failed - error in streaming output\n')
        debug_exc()
        ret= -2
    finally:
        #remove the temp tarfile
        os.remove(temptarfile)
        debug('Removed temp gzipped tarfile - '+temptarfile)

    if ret==-2:
        r=None
        ret=-1
    return ret, r

@auth_required
def start(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/start"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Started container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def stop(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/stop"
    if ns.secs:
        url += "?t="+str(ns.secs)
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Stopped container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def restart(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/restart"
    if ns.secs:
        url += "?t="+str(ns.secs)
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Restarted container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def pause(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/pause"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Paused container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def unpause(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/unpause"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Unpaused container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def rm(ns):
    cont = ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.delete(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Removed container successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def rmi(ns):
    if ns.IMAGE:
        img = ns.IMAGE
    reg=REG_HOST
    if ns.registry:
        reg=ns.registry
    if len(reg) == 0:
        sys.stdout.write ("Error! No registry host specified.\n")
        return -1, None

    auth=_get_registry_auth()
    if ns.psswd:
        auth= "any", ns.psswd

    img=_short_image_name(img)
    tag=_get_image_tag(img)
    img=_strip_image_tag(img)

    url = "https://"+reg+"/v1/repositories/"+img+"/tags/"+tag
    debug("delete url: "+url)

    headers = {
        'Accept': 'application/json'
    }
    try:
        r = requests.delete(url, headers=headers, auth=auth )
        if r.status_code == requests.codes.ok :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ) )
            sys.stdout.write("Removed: "+ns.IMAGE+"\n")
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Image remove failed - Could not connect to container cloud registry\n")
        debug_exc()
        return -1, None
    return 0, r

def _print_images(jobj):
    w=[36, 20, 64]
    hsep=HSEP
    vsep=VSEP

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')

    #print header
    sys.stdout.write ( 'Image Id'.ljust(w[0])[:w[0]] +vsep)
    sys.stdout.write ( 'Created'.ljust(w[1])[:w[1]] + vsep)
    sys.stdout.write ( 'Image Name'.ljust(w[2])[:w[2]] + '\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')

    #iterate over jobj
    for x in jobj:
        sys.stdout.write ( x['Id'].ljust(w[0])[:w[0]] +vsep)
        if not isinstance(x['Created'], int) and not isinstance(x['Created'], float):
            sys.stdout.write ( x['Created'].ljust(w[1])[:w[1]] + vsep)
        else:
            sys.stdout.write ( time.ctime(x['Created'])[4:].ljust(w[1])[:w[1]] + vsep)
        s=_short_image_name(x['Image'])
        sys.stdout.write ( s.ljust(w[2]) + '\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')
    return

@auth_required
def images(ns):
    ''' test formatting
    jobj=json.dumps([
      { "Created": "2014-11-06T21:14:35Z",
        "Id": "e8842ee0-3d15-4e82-8dbf-38cf69cb3369",
        "Image": "docker-registry.mybluemix.net/wfaas/servicebroker:latest"
      },
      {
        "Created": "2014-11-05T16:52:26Z",
        "Id": "e78457b0-0bc4-4119-84b9-cc0f12a79a2f",
        "Image": "cirros-0.3.3-x86"
      }
    ])
    _print_images( json.loads(jobj) )
    return 0
    '''
    url = CCS_HOST_URL+"/images/json"
    debug("request url: "+url)

    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            resp=r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ) )
            _print_images(resp)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

def _print_search_results(jobj):
    w=[64, 40]
    hsep=HSEP
    vsep=VSEP

    sys.stdout.write ('Number of Results:'+str(jobj['num_results']) +'\n')
    sys.stdout.write ('Query:'+jobj['query'] +'\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write  ('\n')

    #print header
    sys.stdout.write ( 'Image name'.ljust(w[0])[:w[0]] +vsep)
    sys.stdout.write ( 'Description'.ljust(w[1])[:w[1]])
    sys.stdout.write  ('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write  ('\n')

    #iterate over jobj
    for x in jobj['results']:
        if x['name']:
            sys.stdout.write ( x['name'].ljust(w[0])[:w[0]] +vsep)
        else:
            sys.stdout.write ( ' '.ljust(w[0])[:w[0]] +vsep)
        if x['description']:
            sys.stdout.write ( x['description'].ljust(w[1])[:w[1]] +vsep)
        sys.stdout.write('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write  ('\n')
    return

@auth_required
def search(ns):
    term=""
    if ns.TERM:
        term=ns.TERM
    reg=REG_HOST
    if ns.registry:
        reg=ns.registry
    if len(reg) == 0:
        sys.stdout.write ("Error! No registry host specified.\n")
        return -1, None

    auth=_get_registry_auth()
    if ns.psswd:
        auth = "any", ns.psswd

    if len(term) > 0 :
        url = "https://"+reg+"/v1/search?q="+term
    else:
        url = "https://"+reg+"/v1/search"
    debug("request url: "+url)

    headers = {
        'Accept': 'application/json'
    }
    try:
        r = requests.get(url, headers=headers, auth=auth )
        if r.status_code == requests.codes.ok :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ) )
            _print_search_results(resp)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Image search failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

def _print_iplist(jobj, all):
    w=[16, 36]
    hsep=HSEP
    vsep=VSEP

    num= len(jobj)
    sys.stdout.write ('Number of addresses: '+ str(num) +'\n')
    if num == 0:
        return
    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')

    #print header
    sys.stdout.write ( 'Ip Address'.ljust(w[0])[:w[0]] +vsep)
    if all:
        sys.stdout.write ( 'Container Id'.ljust(w[1])[:w[1]])
    sys.stdout.write('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')

    #iterate over jobj
    for x in jobj:
        if 'IpAddress' in x and x['IpAddress'] != None:
            sys.stdout.write ( x['IpAddress'].ljust(w[0])[:w[0]] +vsep)
        else:
            sys.stdout.write ( ' '.ljust(w[0])[:w[0]] +vsep)
        if 'ContainerId' in x['Bindings'] and x['Bindings']['ContainerId'] != None:
            sys.stdout.write ( x['Bindings']['ContainerId'].ljust(w[1])[:w[1]] )
        sys.stdout.write('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')
    return

@auth_required
def iplist(ns):
    '''#test formatting
    jobj=json.dumps([
         {
                 "IpAddress": "192.123.12.13",
                 "Bindings": None
         },
         {
                 "IpAddress": "192.123.12.13",
                 "Bindings": {"ContainerId":"963f8846-d6b1-4055-a9f1-6dee7b5f1eea"}
         }
    ])
    _print_iplist( json.loads(jobj) )
    return 0
    '''
    params=""
    if ns.all:
        params="?all=true"
    url = CCS_HOST_URL+"/floating-ips"+params
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ))
            _print_iplist(resp, ns.all)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def ipbind(ns):
    addr=ns.ADDRESS
    cont=ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/floating-ips/"+addr+"/bind"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write("Successfully bound ip \n")
        else:
            _print_err(r)
            if r.status_code == 400 or r.status_code == 404 :
                sys.stdout.write("Could not bind "+addr+" to container "+cont+"\n")
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def ipunbind(ns):
    addr=ns.ADDRESS
    cont=ns.CONTAINER
    url = CCS_HOST_URL+"/"+cont+"/floating-ips/"+addr+"/unbind"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write("Successfully unbound ip \n")
        else:
            _print_err(r)
            if r.status_code == 400 or r.status_code == 404 :
                sys.stdout.write("Could not unbind "+addr+" from container "+cont+"\n")
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def iprequest(ns):
    url = CCS_HOST_URL+"/floating-ips/request"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 200 :
            sys.stdout.write("Successfully obtained ip: "+r.text +'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def iprelease(ns):
    addr=ns.ADDRESS
    url = CCS_HOST_URL+"/floating-ips/"+addr+"/release"
    debug("request url: "+url)
    headers =_create_headers()
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write("Successfully released ip: "+addr +'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def info(ns):
    w=20
    sep = ' : '
    #ice-cfg.ini info
    sys.stdout.write('Debug mode'.ljust(w) +sep +DEBUG_CLI +'\n')
    sys.stdout.write('CCS host/url'.ljust(w) +sep +CCS_HOST_URL +'\n')
    sys.stdout.write('Registry host'.ljust(w) +sep +REG_HOST +'\n')
    sys.stdout.write('Bluemix api host/url'.ljust(w) +sep + CF_API_URL +'\n')
    #sys.stdout.write('API Key'.rjust(w) +sep +API_KEY +'\n')

    #config.json info
    spaceid, spacename, orgid, orgname =_get_cf_config_info()
    if orgname != "":
        sys.stdout.write('Bluemix Org'.ljust(w) +sep +   orgname + ' ('+ orgid +')\n')
    if spacename != "":
        sys.stdout.write('Bluemix Space'.ljust(w) +sep +   spacename + ' ('+ spaceid +')\n')

    try:
        r = _get_namespace()
        if r.status_code == 200 :
            resp=r.json()
            sys.stdout.write('Repository namespace'.ljust(w) +sep +str(resp['namespace'])+'\n')
        else:
            _print_err(r)
            return -1, r

        url = CCS_HOST_URL+"/usage"
        debug("request url: "+url)
        headers = _create_headers()
        r = requests.get(url, headers=headers)
        if r.status_code == 200 :
            resp=r.json()
            sys.stdout.write('Containers limit'.ljust(w) +sep +str(resp['Limits']['containers'])+'\n')

            sys.stdout.write('Containers usage'.ljust(w) +sep +str(resp['Usage']['containers'])+'\n')
            sys.stdout.write('Containers running'.ljust(w) +sep +str(resp['Usage']['running'])+'\n')

            sys.stdout.write('Floating IPs limit'.ljust(w) +sep +str(resp['Limits']['floating_ips'])+'\n')
            sys.stdout.write('Floating IPs usage'.ljust(w) +sep +str(resp['Usage']['floating_ips'])+'\n')

            sys.stdout.write('Memory limit (MB)'.ljust(w) +sep +str(resp['Limits']['memory_MB'])+'\n')
            sys.stdout.write('Memory usage (MB)'.ljust(w) +sep +str(resp['Usage']['memory_MB'])+'\n')
        else:
            _print_err(r)
            return -1, r

        debug(json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ))

    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r


def _print_group_list(jobj):
    w=[36, 16, 20, 19, 19, 6]
    hsep=HSEP
    vsep=VSEP

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep )
    sys.stdout.write ('\n')

    #print header
    sys.stdout.write ( 'Group Id'.ljust(w[0])[:w[0]] +vsep)
    sys.stdout.write ( 'Name'.ljust(w[1])[:w[1]] +vsep )
    sys.stdout.write ( 'Status'.ljust(w[2])[:w[2]] +vsep )
    sys.stdout.write ( 'Created'.ljust(w[3])[:w[3]] +vsep )
    sys.stdout.write ( 'Updated'.ljust(w[4])[:w[4]] +vsep )
    sys.stdout.write ( 'Port'.ljust(w[5])[:w[5]] +vsep )
    sys.stdout.write('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')

    #iterate over jobj
    for x in jobj:
        #strip registry name from image name to shorten it
        #img = x['Image']
        #img=_short_image_name(img)

        sys.stdout.write ( x['Id'].ljust(w[0])[:w[0]] +vsep)
        sys.stdout.write ( x['Name'].ljust(w[1])[:w[1]] +vsep)
        sys.stdout.write ( x['Status'].ljust(w[2])[:w[2]] +vsep)
        if x['Creation_time']:
            sys.stdout.write ( x['Creation_time'].ljust(w[3])[:w[3]] +vsep)
        if x['Updated_time']:
            sys.stdout.write ( x['Updated_time'].ljust(w[4])[:w[4]] +vsep)
        else:
            sys.stdout.write ( ' '.ljust(w[4])[:w[4]] +vsep)
        if "Port" in x and x["Port"] != None:
            sys.stdout.write ( str(x['Port']).ljust(w[5])[:w[5]]+vsep)
        sys.stdout.write('\n')

    #print separator line
    width = sum(w) + len(w) -1
    for i in range(0, width):
        sys.stdout.write (hsep)
    sys.stdout.write ('\n')
    return

@auth_required
def group_list(ns):
    url = CCS_HOST_URL+"/groups"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ))
            _print_group_list(resp)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_create(ns):
    if not ns.name:
        sys.stdout.write('Please specify a name for your group using --name or -n option \n')
        return -1, None
    mem=256
    if ns.memory:
        mem=ns.memory
    env=[]
    if ns.env:
        env=ns.env
    vol=[]
    if ns.vol:
        vol=ns.vol
        for x in vol:
            pos=x.find(":")
            if pos < 1  or  len(x) < (pos+2) :
                sys.stdout.write('Invalid --volume or -v syntax\n')
                return -1, None
    '''
    shares=1024
    if ns.shares:
        shares=ns.shares
    cpus=2
    if ns.cpus:
        mem=ns.cpus
    workdir=""
    if ns.workdir:
        workdir=ns.workdir
    '''
    cmd=[]
    if ns.CMD:
        cmd=ns.CMD
    #image is mandatory positional arg, so it should be found
    image=ns.IMAGE
    if image.find(REG_HOST) == -1:
        image = REG_HOST+'/'+image

    #Currently supported flavors:
    #(256,1) (512,2) (1024,4) (2048,8)
    if not mem in [256, 512, 1024, 2048]:
        sys.stdout.write('Invalid configuration request. Allowed memory configurations are 256, 512, 1024, or 2048 (MB).\n')
        return -1, None
    else:
        cpus = int(mem / 256)

    desired_inst=2
    if ns.desired:
        desired_inst=ns.desired
    min_inst=1
    if ns.min:
        min_inst=ns.min
    max_inst=2
    if ns.max:
        max_inst=ns.max
    autorecovery='false'
    if ns.autorecovery:
        autorecovery='true'

    url = CCS_HOST_URL+"/groups/create"
    debug("request url: "+url)

    data = {
         "Name": ns.name,
         "Memory": mem,
         "CpuShares": 1024,
         "NumberCpus": cpus,
         "Env": env ,
         "Cmd": cmd,
         "Image": image,
         "WorkingDir": "",
         "NumberInstances": {"Desired": desired_inst, "Min" : min_inst, "Max" : max_inst},
         "Autorecovery" : autorecovery,
         "Volumes": vol
    }

    headers = _create_headers()

    #bind to bluemix app if specified
    if ns.app:
        data["BluemixApp"]=ns.app
        CF_TOKEN=_load_cf_token()
        if len(CF_TOKEN) == 0 :
            sys.stdout.write('Could not find cloud foundry token.\n')
            sys.stdout.write('Please install CF command tool in order to be able to bind to Bluemix app.\n')
            return -1, None
        if API_KEY != "":
            headers=_append_header(headers,'X-API-Key', API_KEY)
            headers=_append_header(headers,'X-CF-Token', CF_TOKEN)

    if ns.port:
        data["Port"]=ns.port

    body = json.dumps(data)
    debug("Post body: "+body)
    debug("Headers: "+str(headers))
    try:
        r = requests.post(url, body, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            sys.stdout.write (resp["Id"] +"\n")
            if "Warnings" in resp  and len(resp["Warnings"])>0:
                sys.stdout.write ("Warnings: "+ resp["Warnings"] +"\n")
            sys.stdout.write("Created group "+ ns.name+" (id: "+ resp["Id"]+")\n")
            sys.stdout.write("Minimum container instances: "+str(min_inst)+"\n")
            sys.stdout.write("Maximum container instances: "+str(max_inst)+"\n")
            sys.stdout.write("Desired container instances: "+str(desired_inst)+"\n")
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_update(ns):
    url = CCS_HOST_URL+"/groups/"+ns.GROUP
    debug("request url: "+url)

    data = {"NumberInstances": {}}
    if ns.desired:
        sys.stdout.write("Desired instances must be in the range of current minimum and maximum instances\n")
        data["NumberInstances"]["Desired"]=ns.desired
    if ns.min:
        sys.stdout.write("Minimum instances must be less than or equal to current desired instances\n")
        data["NumberInstances"]["Min"]=ns.min
    if ns.max:
        sys.stdout.write("Maximum instances must be greater than or equal to current desired instances\n")
        data["NumberInstances"]["Max"]=ns.max
    body = json.dumps(data)
    headers = _create_headers()
    debug("Patch body: "+body)
    debug("Headers: "+str(headers))
    try:
        r = requests.patch(url, body, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write ("Group updated successfully\n")
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_rm(ns):
    url = CCS_HOST_URL+"/groups/"+ns.GROUP
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.delete(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Removed group successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_inspect(ns):
    url = CCS_HOST_URL+"/groups/"+ns.GROUP
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == 200 :
            sys.stdout.write( json.dumps( r.json(), sort_keys=True, indent=4, separators=(',', ': ')) +'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_instances(ns):
    url = CCS_HOST_URL+"/json?group="+ns.GROUP
    debug("Get url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == 200 :
            resp=r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')) +'\n')
            _print_containers(resp, PublicIP=False)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def group_health(ns):
    url = CCS_HOST_URL+"/groups/"+ns.GROUP+"/health"
    debug("request url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == 200 :
            sys.stdout.write( json.dumps( r.json(), sort_keys=True, indent=4, separators=(',', ': ')) +'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def route_map(ns):
    #curl -X POST -H "Content-Type: application/json" -H "X-Auth-Token: $CF_TOKEN"  -H "X-Auth-Project-Id: 75834de1-83a1-4029-a108-b7af7da887e3" -d '{"domain": "bluemix.microservices.ninja", "host":"linsun","port":9080}' http://localhost:8081/v2.0/containers/groups/maproute?name=linsun_asg_cwhm_pp

    #old api token users are not enable for this function
    if X_AUTH_TOKEN != '':
        sys.stdout.write("This function is not supported in the experimental version of the service\n")
        return -3, None

    domain=""
    if ns.domain:
        domain=ns.domain
    host=""
    if ns.host:
        host=ns.host
    url = CCS_HOST_URL+"/groups/"+ns.GROUP+"/maproute"
    debug("Post url: "+url)
    body = json.dumps({
        "domain": domain,
        "host": host
    })
    headers = _create_headers()
    debug("Headers: "+str(headers))
    debug("Post body: "+body)
    try:
        if ns.domain or ns.host:
            r = requests.post(url, body, headers=headers)
        else:
            r = requests.post(url, headers=headers)
        if r.status_code == 200 or r.status_code == 201:
            full_name=host+'.'+domain
            debug( json.dumps( r.json(), sort_keys=True, indent=4, separators=(',', ': ')) +'\n')
            sys.stdout.write('Successfully mapped '+ns.GROUP+' to '+ full_name + '\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def route_unmap(ns):
    #curl -X POST -H "Content-Type: application/json" -H "X-Auth-Token: $CF_TOKEN"  -H "X-Auth-Project-Id: 75834de1-83a1-4029-a108-b7af7da887e3"  http://localhost:8081/v2.0/containers/groups/unmaproute?name=linsun_asg_cwhm_pp

    #old api token users are not enable for this function
    if X_AUTH_TOKEN != '':
        sys.stdout.write("This function is not supported in the experimental version of the service\n")
        return -3, None

    domain=""
    if ns.domain:
        domain=ns.domain
    host=""
    if ns.host:
        host=ns.host
    url = CCS_HOST_URL+"/groups/"+ns.GROUP+"/unmaproute"
    debug("Post url: "+url)
    headers = _create_headers()
    debug("Headers: "+str(headers))
    body = json.dumps({
        "domain": domain,
        "host": host
    })
    debug (body)
    try:
        if ns.domain or ns.host:
            r = requests.post(url, body, headers=headers)
        else:
            r = requests.post(url, headers=headers)
        if r.status_code == 200 :
            sys.stdout.write('Successfully unmapped route to '+ns.GROUP+'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

def _print_volume_list(jobj):
    try:
        for x in jobj:
            sys.stdout.write(x["volName"]+ "\n")
    except Exception as e:
        sys.stdout.write(str(jobj)+"\n")
    return

@auth_required
def volume_list(ns):
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="volumes/json"
    debug("Get url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == requests.codes.ok :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ') ))
            _print_volume_list(resp)
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def volume_create(ns):
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="volumes/create?name="+ns.VOLNAME
    debug("Post url: "+url)
    #bearer , space = _get_bearer_and_space()
    headers = _create_headers()
    debug("Headers: "+str(headers))
    try:
        r = requests.post(url, headers=headers)
        if r.status_code == requests.codes.ok or r.status_code == 201 :
            resp = r.json()
            sys.stdout.write("Created volume successfully: "+ns.VOLNAME+"\n")
            debug ( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def volume_rm(ns):
    #bearer, space = _get_bearer_and_space()
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="volumes/"+ns.VOLNAME
    debug("Delete url: "+url)
    headers = _create_headers()
    try:
        r = requests.delete(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write('Removed volume successfully\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def volume_inspect(ns):
    #bearer, space = _get_bearer_and_space()
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="volumes/"+ns.VOLNAME+"/json"
    debug("Get url: "+url)
    headers = _create_headers()
    try:
        r = requests.get(url, headers=headers)
        if r.status_code == 200 :
            resp = r.json()
            sys.stdout.write ( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def set_namespace(ns):
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="registry/namespaces/"+ns.NAME
    debug("PUT url: "+url)
    headers = _create_headers()
    try:
        r = requests.put(url, headers=headers)
        if r.status_code == 201 :
            resp = r.json()
            debug ( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            sys.stdout.write(resp["namespace"]+'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

def _get_namespace():
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="registry/namespaces"
    debug("GET url: "+url)
    headers = _create_headers()
    r = requests.get(url, headers=headers)
    return r

@auth_required
def get_namespace(ns):
    try:
        r = _get_namespace()
        if r.status_code == 200 :
            resp = r.json()
            debug( json.dumps( resp, sort_keys=True, indent=4, separators=(',', ': ')  ))
            name = resp["namespace"]
            sys.stdout.write(name+'\n')
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r

@auth_required
def rm_namespace(ns):
    url = CCS_HOST_URL
    pos=url.find('containers')
    url=url[:pos]
    url+="registry/namespaces"
    debug("DELETE url: "+url)
    headers = _create_headers()
    try:
        r = requests.delete(url, headers=headers)
        if r.status_code == 204 :
            sys.stdout.write("namespace removed \n")
        else:
            _print_err(r)
            return -1, r
    except requests.exceptions.RequestException as e:
        sys.stdout.write("Command failed - Could not connect to container cloud service\n")
        debug_exc()
        return -1, None
    return 0, r
